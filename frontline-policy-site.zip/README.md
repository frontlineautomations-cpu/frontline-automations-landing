# Frontline Automations - Policy & Terms Site

A professional, compliant privacy policy and terms of service website for Frontline Automations, built with Next.js and Tailwind CSS.

## Features

- ✅ **Privacy Policy** - Comprehensive privacy policy covering data collection, usage, and SMS consent
- ✅ **Terms of Service** - Detailed terms covering acceptable use, SMS compliance, and legal requirements
- ✅ **SMS Consent Guidelines** - Complete compliance documentation for TCPA, CTIA, and A2P 10DLC requirements
- ✅ **Responsive Design** - Mobile-friendly and professional appearance
- ✅ **Tab Navigation** - Easy switching between different policy sections

## Compliance Features

Based on SMS compliance requirements, this site includes:

- Clear SMS consent collection guidelines
- Separation of transactional vs. marketing messages
- Required disclosures (who, what, frequency, rates, HELP, STOP)
- Brand name consistency requirements
- A2P 10DLC registration information
- Opt-out procedures and requirements

## Deploy to Vercel

### Quick Deploy

1. Push this code to your GitHub repository
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect Next.js settings
6. Click "Deploy"

### Manual Setup

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

## Customization

Before deploying, update the following placeholders in `app/page.js`:

1. **Contact Information** - Replace `[Your Phone Number]` and `[Your Business Address]` with actual details
2. **Email Addresses** - Update email addresses (privacy@, legal@, compliance@, help@)
3. **Governing Law** - Update `[Your State/Province]` and `[Your Country]` in Terms of Service
4. **Dates** - Update the effective date if needed

## File Structure

```
frontline-policy-site/
├── app/
│   ├── globals.css          # Global styles with Tailwind
│   ├── layout.js            # Root layout component
│   └── page.js              # Main policy page with all content
├── .gitignore               # Git ignore rules
├── next.config.js           # Next.js configuration
├── package.json             # Dependencies and scripts
├── postcss.config.js        # PostCSS configuration
├── tailwind.config.js       # Tailwind CSS configuration
└── README.md               # This file
```

## Technologies Used

- **Next.js 14** - React framework with App Router
- **React 18** - UI library
- **Tailwind CSS** - Utility-first CSS framework
- **Static Export** - Optimized for Vercel deployment

## Important Notes

### Before Going Live

1. ✅ Review all policy content for accuracy
2. ✅ Update contact information and email addresses
3. ✅ Ensure business name matches your DBA and A2P registration exactly
4. ✅ Have legal counsel review policies if needed
5. ✅ Test all links and navigation
6. ✅ Verify mobile responsiveness

### SMS Compliance Critical Requirements

- Phone number entry does NOT equal SMS consent
- Checkbox must be required (not pre-checked)
- Marketing consent must be separate and optional
- Privacy policy must be publicly accessible
- Business name must match DBA/A2P registration exactly

## License

© 2026 Frontline Automations. All rights reserved.

## Support

For questions or issues, contact: [your-email@frontlineautomations.com]
