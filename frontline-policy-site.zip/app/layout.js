import './globals.css'

export const metadata = {
  title: 'Frontline Automations - Privacy & Terms',
  description: 'Privacy Policy and Terms of Service for Frontline Automations',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
