'use client';

import { useState } from 'react';

export default function PolicyPage() {
  const [activeTab, setActiveTab] = useState('privacy');
  const currentDate = 'February 14, 2026';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <h1 className="text-4xl font-bold text-slate-900">Frontline Automations</h1>
          <p className="text-slate-600 mt-2">Legal Information & Compliance</p>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="max-w-4xl mx-auto px-6 mt-8 mb-12">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className="flex border-b border-slate-200">
            <button
              onClick={() => setActiveTab('privacy')}
              className={`flex-1 px-8 py-5 font-semibold text-lg transition-all ${
                activeTab === 'privacy'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Privacy Policy
            </button>
            <button
              onClick={() => setActiveTab('terms')}
              className={`flex-1 px-8 py-5 font-semibold text-lg transition-all ${
                activeTab === 'terms'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              Terms of Service
            </button>
            <button
              onClick={() => setActiveTab('sms')}
              className={`flex-1 px-8 py-5 font-semibold text-lg transition-all ${
                activeTab === 'sms'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              SMS Consent
            </button>
          </div>

          {/* Content Area */}
          <div className="p-10">
            {activeTab === 'privacy' && <PrivacyPolicy />}
            {activeTab === 'terms' && <TermsOfService />}
            {activeTab === 'sms' && <SMSConsent />}
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-4xl mx-auto px-6">
          <div className="text-center">
            <p className="text-lg font-semibold">Frontline Automations</p>
            <p className="mt-2 text-slate-400">© {new Date().getFullYear()} All rights reserved.</p>
            <p className="mt-4 text-sm text-slate-400">Last updated: {currentDate}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function PrivacyPolicy() {
  return (
    <div className="prose prose-slate max-w-none">
      <h2 className="text-3xl font-bold text-slate-900 mb-8">Privacy Policy</h2>
      
      <div className="bg-blue-50 border-l-4 border-blue-600 p-6 mb-8">
        <p className="text-slate-700 font-medium">
          Effective Date: February 14, 2026
        </p>
      </div>

      <Section title="1. Introduction">
        <p className="text-slate-700 leading-relaxed">
          Frontline Automations ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our automation services, including SMS and communication platforms.
        </p>
      </Section>

      <Section title="2. Information We Collect">
        <h4 className="font-semibold text-slate-900 mt-4 mb-2">Personal Information</h4>
        <p className="text-slate-700 leading-relaxed mb-4">
          We may collect personal information that you provide to us, including but not limited to:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Name and contact information (email address, phone number, mailing address)</li>
          <li>Business name and DBA (Doing Business As) information</li>
          <li>Account credentials and login information</li>
          <li>Payment and billing information</li>
          <li>Communication preferences and consent records</li>
        </ul>

        <h4 className="font-semibold text-slate-900 mt-6 mb-2">Automatically Collected Information</h4>
        <p className="text-slate-700 leading-relaxed mb-4">
          When you use our services, we automatically collect certain information:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Device information (IP address, browser type, operating system)</li>
          <li>Usage data (pages viewed, features used, time spent)</li>
          <li>Log files and analytics data</li>
          <li>Cookies and similar tracking technologies</li>
        </ul>
      </Section>

      <Section title="3. How We Use Your Information">
        <p className="text-slate-700 leading-relaxed mb-4">
          We use the information we collect for the following purposes:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>To provide, maintain, and improve our automation services</li>
          <li>To process transactions and send related information</li>
          <li>To send administrative messages, updates, and security alerts</li>
          <li>To respond to your comments, questions, and customer service requests</li>
          <li>To communicate with you about products, services, and promotional offers (with your consent)</li>
          <li>To monitor and analyze usage trends and preferences</li>
          <li>To detect, prevent, and address technical issues and fraudulent activity</li>
          <li>To comply with legal obligations and enforce our terms</li>
        </ul>
      </Section>

      <Section title="4. SMS and Communication Consent">
        <p className="text-slate-700 leading-relaxed mb-4">
          When you provide your phone number and consent to receive SMS messages:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li><strong>Entering a phone number alone does not grant permission to send SMS messages</strong></li>
          <li>SMS consent must be collected separately and explicitly using compliant opt-in methods</li>
          <li>Consent for non-promotional messages (transactional notifications) must be separate from marketing content</li>
          <li>A checkbox must be required to submit any form collecting SMS consent</li>
          <li>Privacy policy and terms must be publicly accessible and clearly state that SMS consent is not shared with third parties (except SMS providers)</li>
          <li>The business name shown must exactly match the Brand Name declared in DBA registration and A2P registration sample messages</li>
        </ul>

        <div className="bg-amber-50 border-l-4 border-amber-500 p-6 mt-6">
          <p className="text-amber-900 font-medium mb-2">SMS Disclosure Requirements</p>
          <p className="text-amber-800 text-sm leading-relaxed">
            All SMS communications must clearly state: (1) Who is sending messages (business name), (2) What type of messages will be sent, (3) Message frequency (e.g., "may vary"), (4) That message and data rates may apply, (5) How to get HELP, and (6) How to opt out (STOP).
          </p>
        </div>
      </Section>

      <Section title="5. Information Sharing and Disclosure">
        <p className="text-slate-700 leading-relaxed mb-4">
          We do not sell your personal information. We may share your information in the following circumstances:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li><strong>Service Providers:</strong> We share information with third-party service providers who perform services on our behalf (e.g., SMS delivery providers, payment processors, analytics providers)</li>
          <li><strong>Business Transfers:</strong> In connection with a merger, acquisition, or sale of assets</li>
          <li><strong>Legal Requirements:</strong> When required by law or to protect our rights and safety</li>
          <li><strong>With Your Consent:</strong> When you explicitly consent to sharing your information</li>
        </ul>

        <p className="text-slate-700 leading-relaxed mt-4">
          <strong>Important:</strong> SMS consent is not shared with third parties except for the SMS provider necessary to deliver messages.
        </p>
      </Section>

      <Section title="6. Data Security">
        <p className="text-slate-700 leading-relaxed">
          We implement appropriate technical and organizational security measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no method of transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
        </p>
      </Section>

      <Section title="7. Your Rights and Choices">
        <p className="text-slate-700 leading-relaxed mb-4">
          You have the following rights regarding your personal information:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li><strong>Access:</strong> Request access to the personal information we hold about you</li>
          <li><strong>Correction:</strong> Request correction of inaccurate or incomplete information</li>
          <li><strong>Deletion:</strong> Request deletion of your personal information</li>
          <li><strong>Opt-Out:</strong> Opt out of marketing communications at any time</li>
          <li><strong>SMS Opt-Out:</strong> Reply STOP to any SMS message to unsubscribe</li>
          <li><strong>Data Portability:</strong> Request a copy of your data in a portable format</li>
        </ul>

        <p className="text-slate-700 leading-relaxed mt-4">
          To exercise these rights, please contact us using the information provided at the end of this policy.
        </p>
      </Section>

      <Section title="8. Cookies and Tracking Technologies">
        <p className="text-slate-700 leading-relaxed">
          We use cookies and similar tracking technologies to collect information about your browsing activities. You can control cookies through your browser settings. Note that disabling cookies may limit your ability to use certain features of our services.
        </p>
      </Section>

      <Section title="9. Third-Party Links">
        <p className="text-slate-700 leading-relaxed">
          Our services may contain links to third-party websites. We are not responsible for the privacy practices of these external sites. We encourage you to review their privacy policies before providing any personal information.
        </p>
      </Section>

      <Section title="10. Children's Privacy">
        <p className="text-slate-700 leading-relaxed">
          Our services are not intended for children under 13 years of age. We do not knowingly collect personal information from children. If you believe we have collected information from a child, please contact us immediately.
        </p>
      </Section>

      <Section title="11. Changes to This Privacy Policy">
        <p className="text-slate-700 leading-relaxed">
          We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page and updating the "Last Updated" date. Your continued use of our services after changes are posted constitutes acceptance of the updated policy.
        </p>
      </Section>

      <Section title="12. Contact Us">
        <p className="text-slate-700 leading-relaxed mb-4">
          If you have questions or concerns about this Privacy Policy, please contact us at:
        </p>
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          <p className="font-semibold text-slate-900">Frontline Automations</p>
          <p className="text-slate-700 mt-2">Email: privacy@frontlineautomations.com</p>
          <p className="text-slate-700">Phone: [Your Phone Number]</p>
          <p className="text-slate-700">Address: [Your Business Address]</p>
        </div>
      </Section>
    </div>
  );
}

function TermsOfService() {
  return (
    <div className="prose prose-slate max-w-none">
      <h2 className="text-3xl font-bold text-slate-900 mb-8">Terms of Service</h2>
      
      <div className="bg-blue-50 border-l-4 border-blue-600 p-6 mb-8">
        <p className="text-slate-700 font-medium">
          Effective Date: February 14, 2026
        </p>
      </div>

      <Section title="1. Acceptance of Terms">
        <p className="text-slate-700 leading-relaxed">
          By accessing or using Frontline Automations services ("Services"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree to these Terms, do not use our Services. We reserve the right to modify these Terms at any time, and your continued use constitutes acceptance of any changes.
        </p>
      </Section>

      <Section title="2. Description of Services">
        <p className="text-slate-700 leading-relaxed">
          Frontline Automations provides business automation solutions, including but not limited to workflow automation, SMS communication platforms, integration services, and related tools. We reserve the right to modify, suspend, or discontinue any aspect of our Services at any time.
        </p>
      </Section>

      <Section title="3. Account Registration and Security">
        <p className="text-slate-700 leading-relaxed mb-4">
          To use certain features of our Services, you must register for an account. You agree to:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Provide accurate, current, and complete information during registration</li>
          <li>Maintain and update your information to keep it accurate and current</li>
          <li>Maintain the security of your account credentials</li>
          <li>Notify us immediately of any unauthorized access or security breach</li>
          <li>Accept responsibility for all activities under your account</li>
        </ul>
      </Section>

      <Section title="4. Acceptable Use Policy">
        <p className="text-slate-700 leading-relaxed mb-4">
          You agree not to use our Services to:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Violate any applicable laws, regulations, or third-party rights</li>
          <li>Send unsolicited or unauthorized communications (spam)</li>
          <li>Transmit malicious code, viruses, or harmful components</li>
          <li>Interfere with or disrupt the Services or servers</li>
          <li>Attempt to gain unauthorized access to any systems or networks</li>
          <li>Impersonate any person or entity or misrepresent your affiliation</li>
          <li>Harass, abuse, or harm others</li>
          <li>Collect or harvest personal information without consent</li>
        </ul>
      </Section>

      <Section title="5. SMS Communication Compliance">
        <p className="text-slate-700 leading-relaxed mb-4">
          If you use our SMS communication features, you must comply with all applicable laws and regulations, including but not limited to:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>The Telephone Consumer Protection Act (TCPA)</li>
          <li>CAN-SPAM Act requirements</li>
          <li>Cellular Telecommunications Industry Association (CTIA) guidelines</li>
          <li>Carrier-specific messaging policies and A2P 10DLC registration requirements</li>
        </ul>

        <div className="bg-red-50 border-l-4 border-red-600 p-6 mt-6">
          <p className="text-red-900 font-semibold mb-2">Critical Compliance Requirements</p>
          <ul className="list-disc pl-5 space-y-1 text-red-800 text-sm">
            <li>You must obtain express written consent before sending SMS messages</li>
            <li>Entering a phone number does NOT constitute consent</li>
            <li>Consent for promotional messages must be separate from transactional messages</li>
            <li>You must provide clear opt-out mechanisms (STOP) and honor opt-out requests immediately</li>
            <li>Your business name in messages must match your registered DBA and A2P registration</li>
            <li>You must include required disclosures in all SMS communications</li>
          </ul>
        </div>

        <p className="text-slate-700 leading-relaxed mt-6">
          You are solely responsible for ensuring compliance with all SMS regulations. Frontline Automations is not liable for your non-compliance or any resulting penalties.
        </p>
      </Section>

      <Section title="6. Payment Terms">
        <p className="text-slate-700 leading-relaxed mb-4">
          If you purchase paid Services:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>You agree to pay all fees according to the pricing and payment terms presented to you</li>
          <li>All fees are non-refundable unless otherwise stated</li>
          <li>You authorize us to charge your payment method on a recurring basis for subscription services</li>
          <li>We reserve the right to change our pricing with advance notice</li>
          <li>Failure to pay may result in suspension or termination of Services</li>
        </ul>
      </Section>

      <Section title="7. Intellectual Property Rights">
        <p className="text-slate-700 leading-relaxed mb-4">
          All content, features, and functionality of our Services are owned by Frontline Automations and are protected by copyright, trademark, and other intellectual property laws. You are granted a limited, non-exclusive, non-transferable license to access and use the Services for your business purposes.
        </p>
        <p className="text-slate-700 leading-relaxed">
          You retain ownership of any content you upload or create using our Services. By using our Services, you grant us a license to use, store, and process your content solely to provide the Services.
        </p>
      </Section>

      <Section title="8. Data and Privacy">
        <p className="text-slate-700 leading-relaxed">
          Your use of our Services is also governed by our Privacy Policy. By using our Services, you consent to our collection and use of your information as described in the Privacy Policy.
        </p>
      </Section>

      <Section title="9. Third-Party Services">
        <p className="text-slate-700 leading-relaxed">
          Our Services may integrate with or contain links to third-party services, applications, or websites. We are not responsible for the content, accuracy, or practices of third-party services. Your use of third-party services is governed by their respective terms and policies.
        </p>
      </Section>

      <Section title="10. Warranties and Disclaimers">
        <p className="text-slate-700 leading-relaxed mb-4">
          OUR SERVICES ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Warranties of merchantability or fitness for a particular purpose</li>
          <li>Warranties that the Services will be uninterrupted, error-free, or secure</li>
          <li>Warranties regarding the accuracy or reliability of any content</li>
        </ul>
      </Section>

      <Section title="11. Limitation of Liability">
        <p className="text-slate-700 leading-relaxed">
          TO THE MAXIMUM EXTENT PERMITTED BY LAW, FRONTLINE AUTOMATIONS SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR REVENUES, WHETHER INCURRED DIRECTLY OR INDIRECTLY, OR ANY LOSS OF DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES RESULTING FROM YOUR USE OF THE SERVICES.
        </p>
        <p className="text-slate-700 leading-relaxed mt-4">
          OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID US IN THE 12 MONTHS PRECEDING THE CLAIM.
        </p>
      </Section>

      <Section title="12. Indemnification">
        <p className="text-slate-700 leading-relaxed">
          You agree to indemnify, defend, and hold harmless Frontline Automations and its officers, directors, employees, and agents from any claims, liabilities, damages, losses, and expenses arising from your use of the Services, violation of these Terms, or violation of any rights of a third party.
        </p>
      </Section>

      <Section title="13. Termination">
        <p className="text-slate-700 leading-relaxed mb-4">
          We may terminate or suspend your account and access to the Services:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>For violation of these Terms</li>
          <li>For non-payment of fees</li>
          <li>For conduct that we believe is harmful to us, other users, or third parties</li>
          <li>At our discretion, with or without notice</li>
        </ul>
        <p className="text-slate-700 leading-relaxed mt-4">
          You may terminate your account at any time by contacting us. Upon termination, your right to use the Services will immediately cease.
        </p>
      </Section>

      <Section title="14. Governing Law and Dispute Resolution">
        <p className="text-slate-700 leading-relaxed">
          These Terms are governed by the laws of [Your State/Province] and [Your Country], without regard to conflict of law principles. Any disputes arising from these Terms or the Services shall be resolved through binding arbitration in accordance with [Arbitration Rules], except where prohibited by law.
        </p>
      </Section>

      <Section title="15. Severability">
        <p className="text-slate-700 leading-relaxed">
          If any provision of these Terms is found to be invalid or unenforceable, the remaining provisions will remain in full force and effect.
        </p>
      </Section>

      <Section title="16. Entire Agreement">
        <p className="text-slate-700 leading-relaxed">
          These Terms, together with our Privacy Policy, constitute the entire agreement between you and Frontline Automations regarding the Services and supersede all prior agreements and understandings.
        </p>
      </Section>

      <Section title="17. Contact Information">
        <p className="text-slate-700 leading-relaxed mb-4">
          For questions about these Terms of Service, contact us at:
        </p>
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          <p className="font-semibold text-slate-900">Frontline Automations</p>
          <p className="text-slate-700 mt-2">Email: legal@frontlineautomations.com</p>
          <p className="text-slate-700">Phone: [Your Phone Number]</p>
          <p className="text-slate-700">Address: [Your Business Address]</p>
        </div>
      </Section>
    </div>
  );
}

function SMSConsent() {
  return (
    <div className="prose prose-slate max-w-none">
      <h2 className="text-3xl font-bold text-slate-900 mb-8">SMS Consent & Compliance</h2>
      
      <div className="bg-amber-50 border-l-4 border-amber-500 p-6 mb-8">
        <p className="text-amber-900 font-semibold mb-2">Important Compliance Information</p>
        <p className="text-amber-800 leading-relaxed">
          This page outlines the requirements for SMS consent collection and compliance with telecommunications regulations including TCPA, CTIA guidelines, and A2P 10DLC requirements.
        </p>
      </div>

      <Section title="SMS Consent Requirements">
        <div className="bg-white border-2 border-blue-600 p-6 rounded-lg mb-6">
          <h4 className="font-bold text-blue-900 mb-4 text-lg">Critical Rule</h4>
          <p className="text-slate-800 font-semibold text-lg leading-relaxed">
            Entering a phone number alone does NOT grant permission to send SMS messages.
          </p>
        </div>

        <p className="text-slate-700 leading-relaxed mb-4">
          SMS consent must be collected separately and explicitly using the following compliant methods:
        </p>

        <div className="space-y-6">
          <div className="bg-slate-50 p-6 rounded-lg border border-slate-300">
            <h5 className="font-semibold text-slate-900 mb-3">1. Checkbox Requirement</h5>
            <p className="text-slate-700 leading-relaxed mb-3">
              A checkbox must be required to submit the form. The checkbox cannot be pre-checked and must clearly indicate consent.
            </p>
            <div className="bg-white p-4 border-l-4 border-green-500 text-sm font-mono">
              <p className="text-slate-700">☐ I consent to receive SMS messages from Frontline Automations.</p>
            </div>
          </div>

          <div className="bg-slate-50 p-6 rounded-lg border border-slate-300">
            <h5 className="font-semibold text-slate-900 mb-3">2. Separate Consent Types</h5>
            <p className="text-slate-700 leading-relaxed">
              Consent for non-promotional messages (transactional/operational notifications) must be separate from consent for marketing content. It must be separate and optional.
            </p>
            <ul className="list-disc pl-6 space-y-2 text-slate-700 mt-3">
              <li><strong>Transactional:</strong> Order confirmations, appointment reminders, account alerts</li>
              <li><strong>Marketing/Promotional:</strong> Sales, offers, newsletters, promotional content</li>
            </ul>
          </div>

          <div className="bg-slate-50 p-6 rounded-lg border border-slate-300">
            <h5 className="font-semibold text-slate-900 mb-3">3. Brand Name Consistency</h5>
            <p className="text-slate-700 leading-relaxed">
              The business name shown must exactly match the Brand Name declared in DBA registration and A2P registration sample messages. Any discrepancy will result in message filtering or blocking.
            </p>
          </div>

          <div className="bg-slate-50 p-6 rounded-lg border border-slate-300">
            <h5 className="font-semibold text-slate-900 mb-3">4. Public Accessibility</h5>
            <p className="text-slate-700 leading-relaxed">
              Privacy policy and terms must be publicly accessible. They must clearly state that SMS consent is not shared with third parties (except SMS providers necessary for message delivery).
            </p>
          </div>
        </div>
      </Section>

      <Section title="Required SMS Disclosures">
        <p className="text-slate-700 leading-relaxed mb-4">
          All SMS communications and consent forms must clearly state the following:
        </p>

        <div className="bg-blue-50 border border-blue-300 p-6 rounded-lg space-y-4">
          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ Who is sending messages</p>
            <p className="text-slate-700 text-sm">Business name (must match Brand Name registration)</p>
          </div>

          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ What type of messages will be sent</p>
            <p className="text-slate-700 text-sm">Describe message content (e.g., "appointment reminders" or "promotional offers")</p>
          </div>

          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ Message frequency</p>
            <p className="text-slate-700 text-sm">E.g., "may vary", "up to 4 msgs/month", or specific frequency</p>
          </div>

          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ Message and data rates may apply</p>
            <p className="text-slate-700 text-sm">Standard disclosure that carrier charges may apply</p>
          </div>

          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ How to get HELP</p>
            <p className="text-slate-700 text-sm">Reply HELP for assistance or provide support contact</p>
          </div>

          <div>
            <p className="font-semibold text-blue-900 mb-2">✓ How to opt out (STOP)</p>
            <p className="text-slate-700 text-sm">Reply STOP to unsubscribe at any time</p>
          </div>
        </div>
      </Section>

      <Section title="Example Compliant SMS Consent Language">
        <div className="bg-slate-900 text-slate-100 p-6 rounded-lg font-mono text-sm leading-relaxed">
          <p className="mb-4">
            <span className="text-green-400">☐</span> I consent to receive transactional SMS messages from Frontline Automations at the phone number provided. These messages may include appointment reminders, order updates, and account notifications.
          </p>
          <p className="mb-4">
            <span className="text-green-400">☐</span> I consent to receive promotional SMS messages from Frontline Automations at the phone number provided. These messages may include special offers, news, and marketing content.
          </p>
          <p className="text-slate-300 text-xs mt-6 border-t border-slate-700 pt-4">
            Message frequency may vary. Message and data rates may apply. Reply HELP for help or STOP to opt out at any time. Your consent is not shared with third parties except our SMS provider. View our Privacy Policy and Terms of Service for more information.
          </p>
        </div>
      </Section>

      <Section title="Marketing vs. Transactional Messages">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-green-50 border-2 border-green-600 p-6 rounded-lg">
            <h5 className="font-bold text-green-900 mb-4">Transactional Messages</h5>
            <ul className="space-y-2 text-slate-700 text-sm">
              <li>✓ Order confirmations</li>
              <li>✓ Shipping notifications</li>
              <li>✓ Appointment reminders</li>
              <li>✓ Password resets</li>
              <li>✓ Account security alerts</li>
              <li>✓ Service status updates</li>
            </ul>
            <p className="text-xs text-green-800 mt-4 font-medium">
              Require basic consent but have more flexible rules
            </p>
          </div>

          <div className="bg-purple-50 border-2 border-purple-600 p-6 rounded-lg">
            <h5 className="font-bold text-purple-900 mb-4">Marketing Messages</h5>
            <ul className="space-y-2 text-slate-700 text-sm">
              <li>✓ Promotional offers</li>
              <li>✓ Sales announcements</li>
              <li>✓ Newsletters</li>
              <li>✓ Event invitations</li>
              <li>✓ Product recommendations</li>
              <li>✓ Surveys and feedback requests</li>
            </ul>
            <p className="text-xs text-purple-800 mt-4 font-medium">
              Require express written consent and strict compliance
            </p>
          </div>
        </div>

        <div className="bg-red-50 border-l-4 border-red-600 p-6 mt-6">
          <p className="text-red-900 font-semibold mb-2">⚠️ Important</p>
          <p className="text-red-800 text-sm leading-relaxed">
            Marketing SMS content cannot be mandatory and cannot block form submission. It must be separate and optional. Consent must be unchecked by default.
          </p>
        </div>
      </Section>

      <Section title="Opt-Out Requirements">
        <p className="text-slate-700 leading-relaxed mb-4">
          You must honor opt-out requests immediately (within the same business day) and provide multiple ways to opt out:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li><strong>STOP keyword:</strong> Users can reply STOP to any message to unsubscribe</li>
          <li><strong>HELP keyword:</strong> Users can reply HELP to get assistance and support contact info</li>
          <li><strong>Alternative methods:</strong> Provide email or web-based opt-out options</li>
          <li><strong>Confirmation:</strong> Send a confirmation message after opt-out is processed</li>
        </ul>

        <div className="bg-slate-100 p-6 rounded-lg mt-6 border border-slate-300">
          <p className="font-semibold text-slate-900 mb-3">Example Auto-Responses:</p>
          <div className="space-y-3 text-sm font-mono">
            <div className="bg-white p-3 rounded border-l-4 border-blue-500">
              <p className="text-slate-600 text-xs mb-1">User sends: STOP</p>
              <p className="text-slate-900">"You have been unsubscribed from Frontline Automations messages. Reply START to resubscribe. For help, reply HELP."</p>
            </div>
            <div className="bg-white p-3 rounded border-l-4 border-green-500">
              <p className="text-slate-600 text-xs mb-1">User sends: HELP</p>
              <p className="text-slate-900">"Frontline Automations: For support, email help@frontlineautomations.com or call [phone]. Reply STOP to unsubscribe. Msg&data rates may apply."</p>
            </div>
          </div>
        </div>
      </Section>

      <Section title="A2P 10DLC Registration">
        <p className="text-slate-700 leading-relaxed mb-4">
          Application-to-Person (A2P) 10DLC registration is required for business SMS messaging in the United States. This registration process includes:
        </p>
        <ul className="list-disc pl-6 space-y-2 text-slate-700">
          <li>Business registration with The Campaign Registry (TCR)</li>
          <li>Brand verification and vetting</li>
          <li>Campaign (use case) registration</li>
          <li>Sample message submission showing exact consent language</li>
        </ul>
        <p className="text-slate-700 leading-relaxed mt-4">
          <strong>Critical:</strong> The business name used in messages must exactly match the registered Brand Name and DBA information provided during A2P registration. Mismatches can result in message filtering, blocking, or campaign suspension.
        </p>
      </Section>

      <Section title="Compliance Checklist">
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-600 p-8 rounded-lg">
          <h4 className="font-bold text-slate-900 mb-6 text-lg">Before Sending SMS Messages:</h4>
          <div className="space-y-3">
            {[
              'Express written consent obtained via compliant opt-in form',
              'Consent checkbox is required (not pre-checked)',
              'Marketing consent is separate and optional from transactional consent',
              'Privacy Policy and Terms of Service are publicly accessible',
              'All required disclosures are clearly stated (who, what, frequency, rates, HELP, STOP)',
              'Business name matches DBA and A2P registration exactly',
              'A2P 10DLC registration is complete and approved',
              'STOP and HELP keyword responses are configured',
              'Opt-out process is immediate and functional',
              'Message content matches registered campaign use case',
            ].map((item, index) => (
              <div key={index} className="flex items-start">
                <span className="text-green-600 mr-3 text-xl">☐</span>
                <span className="text-slate-700">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section title="Contact for Compliance Questions">
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          <p className="text-slate-700 leading-relaxed mb-4">
            If you have questions about SMS compliance or need assistance with consent implementation:
          </p>
          <p className="font-semibold text-slate-900">Frontline Automations</p>
          <p className="text-slate-700 mt-2">Email: compliance@frontlineautomations.com</p>
          <p className="text-slate-700">Phone: [Your Phone Number]</p>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <section className="mb-10">
      <h3 className="text-xl font-bold text-slate-900 mb-4">{title}</h3>
      <div className="space-y-4">
        {children}
      </div>
    </section>
  );
}
